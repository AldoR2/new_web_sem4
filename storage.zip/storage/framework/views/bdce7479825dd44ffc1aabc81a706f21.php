<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/admin/data-matkul.js']); ?>

    <div class="relative dark:text-white">
         <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
        <p class="text-gray-700 dark:text-gray-300">Daftar Seluruh Mata Kuliah</p>

        <div x-data="{openImport: false}" class="w-full overflow-x-auto max-w-full mt-5 p-5 bg-white dark:bg-gray-800 rounded-sm shadow-xl">

            <div class="flex flex-col xl:flex-row">
                <!-- Program Studi -->
                <div class="flex flex-col w-full mb-4 xl:w-1/3 mr-0 md:mr-4">
                    <label for="prodi" class="mb-1 font-semibold text-gray-800 dark:text-gray-200">Filter By Program Studi:</label>
                    <select id="prodi" name="prodi" class="dark:bg-gray-700 dark:text-white dark:border-gray-600">
                        <option value="" hidden selected>Pilih Program Studi</option>
                        <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama_prodi); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Semester -->
                <div class="flex flex-col w-full mb-4 xl:w-1/3 mr-0 md:mr-4">
                    <label for="semester" class="mb-1 font-semibold text-gray-800 dark:text-gray-200">Filter By Semester:</label>
                    <select id="semester" name="semester" class="dark:bg-gray-700 dark:text-white dark:border-gray-600">
                        <option value="" hidden selected>Pilih Semester</option>
                        <?php for($i = 1; $i <= 8; $i++): ?>
                            <option value="<?php echo e($i); ?>"> Semester <?php echo e($i); ?> </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <!-- Tahun Ajaran -->
                <div class="flex flex-col w-full mb-4 xl:w-1/3">
                    <label for="tahun_ajaran" class="mb-1 font-semibold text-gray-800 dark:text-gray-200">Filter By Tahun Ajaran:</label>
                    <select id="tahun_ajaran" name="tahun_ajaran" class="dark:bg-gray-700 dark:text-white dark:border-gray-600">
                        <option value="" hidden selected>Pilih Tahun Ajaran</option>
                        <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($t->id); ?>">
                                <?php echo e($t->tahun_awal .'/'. $t->tahun_akhir .' '. $t->keterangan); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="w-full overflow-x-auto max-w-full mt-3 p-5 bg-white dark:bg-gray-800 rounded-sm shadow-xl">
            <div class="mt-2 mb-5 flex gap-4">
                <a href="<?php echo e(route('admin.master-matkul.create')); ?>">
                    <button class="flex items-center px-4 py-2.5 text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-sm font-semibold cursor-pointer">
                        <i class="bi bi-plus-square-fill mr-2"></i>
                        <span>Tambah</span>
                    </button>
                </a>
            </div>

            <div class="overflow-x-auto w-[270px] sm:w-150 md:w-full mt-3 pb-3">
                <table id="data-matkul" class="text-sm w-full pt-1 display nowrap dark:text-white">
                    <thead class="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 sticky top-0 z-10">
                        <tr>
                            <th class=" dark:border-gray-600 px-4 py-2">No</th>
                            <th class=" dark:border-gray-600 px-4 py-2">Nama Mata Kuliah</th>
                            <th class=" dark:border-gray-600 px-4 py-2">Program Studi</th>
                            <th class=" dark:border-gray-600 px-4 py-2">SKS</th>
                            <th class=" dark:border-gray-600 px-4 py-2">Tahun Ajaran</th>
                            <th class=" dark:border-gray-600 px-4 py-2 !text-center">Semester</th>
                            <th class=" dark:border-gray-600 px-4 py-2 !text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-800">
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($loop->iteration); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($m->nama_matkul); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($m->prodi->nama_prodi ?? ''); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($m->durasi_matkul); ?> SKS</td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($m->tahunAjaran->tahun_awal .'/'. $m->tahunAjaran->tahun_akhir .' '.$m->tahunAjaran->keterangan ?? ''); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2 text-center"><?php echo e($m->semester); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2 text-center">
                                    <div class="flex justify-center gap-2">
                                        <a href="<?php echo e(route('admin.master-matkul.edit', $m->id)); ?>" class="cursor-pointer px-2 py-1 bg-yellow-600 hover:bg-yellow-700 active:bg-yellow-800 text-white rounded-md">
                                            <i class="bi bi-pencil-square text-lg"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.master-matkul.destroy', $m->id)); ?>" method="POST" class="form-hapus inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="px-2 py-1 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white rounded-md">
                                                <i class="bi bi-trash text-lg"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project_web_sem4-main lokal\resources\views/admin/master_data/matkul.blade.php ENDPATH**/ ?>