<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/admin/rekap-dosen.js']); ?>
<div class="h-full dark:bg-gray-700 dark:text-white">
 <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
<p class="text-lg">Lihat Rekap Presensi Dosen</p>

<div class="w-full h-max max-w-full mt-5 p-8 bg-white dark:bg-gray-800 rounded-sm shadow-xl">
   <form action="<?php echo e(route('admin.rekap-dosen.filter')); ?>" method="POST">
       <?php echo csrf_field(); ?>
 <div class="flex flex-col md:flex-row">
       <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0 md:mr-8">
           <label for="dosen" class="mb-1 font-semibold">Pilih Dosen:</label>
           <select id="dosen" name="dosen" class="bg-white dark:bg-gray-700 dark:text-white border dark:border-gray-600 rounded px-3 py-2" required>
               <option value="" hidden selected>Pilih Program Studi</option>
               <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($d->id); ?>"><?php echo e($d->nama); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
       </div>

       <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0">
           <label for="tahun-ajaran" class="mb-1 font-semibold">Pilih Tahun Ajaran:</label>
           <select id="tahun-ajaran" name="tahun_ajaran" class="bg-white dark:bg-gray-700 dark:text-white border dark:border-gray-600 rounded px-3 py-2 w-full" required>
               <option value="" hidden selected>Pilih Tahun Ajaran</option>
               <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($t->id); ?>">
                       <?php echo e($t->tahun_awal .'/'. $t->tahun_akhir .' '. $t->keterangan); ?>

                   </option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
       </div>
   </div>

   <div class="w-full flex justify-end mb-6">
       <a href="<?php echo e(route('admin.rekap-dosen.index')); ?>" class="px-5 py-2 mr-2 bg-red-500 hover:bg-red-600 active:bg-red-700 text-white font-semibold rounded-md cursor-pointer">Reset</a>
       <button type="submit" class="px-5 py-2 bg-green-600 hover:bg-green-700 active:bg-green-800 text-white rounded-md font-semibold cursor-pointer">Cari</button>
   </div>
   </form>

<?php if($dosenTerpilih && $tahunTerpilih): ?>
   <div class="mt-2 mb-5 flex gap-4">
       <form action="<?php echo e(route('admin.export.dosen.excel')); ?>" method="POST">
           <?php echo csrf_field(); ?>
           <input type="hidden" name="dosen" value="<?php echo e(request('dosen')); ?>">
           <input type="hidden" name="tahun_ajaran" value="<?php echo e(request('tahun_ajaran')); ?>">

           <button class="flex items-center px-4 py-2.5 text-white bg-green-700 hover:bg-green-800 active:bg-green-900 rounded-sm font-semibold cursor-pointer">
               <i class="bi bi-file-earmark-excel mr-2"></i>
               <span>Export Excel</span>
           </button>
       </form>

       <form action="<?php echo e(route('admin.export.dosen.pdf')); ?>" method="POST">
           <?php echo csrf_field(); ?>
           <input type="hidden" name="dosen" value="<?php echo e(request('dosen')); ?>">
           <input type="hidden" name="tahun_ajaran" value="<?php echo e(request('tahun_ajaran')); ?>">

           <button type="submit" class="flex items-center px-4 py-2.5 text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-sm font-semibold cursor-pointer">
               <i class="bi bi-filetype-pdf mr-2"></i>
               <span>Export PDF</span>
           </button>
       </form>
   </div>

   <div class="flex flex-col gap-3 mt-3">
       <div class="flex flex-col md:flex-row items-start md:items-center gap-2">
           <span for="nip" class="w-20 font-semibold">NIP:</span>
           <span class="border border-gray-100 dark:border-gray-600 bg-gray-150 dark:bg-gray-700 rounded px-3 py-2 w-full"><?php echo e($dosenTerpilih->nip ?? ''); ?></span>
       </div>

       <div class="flex flex-col md:flex-row items-start md:items-center gap-2">
           <span for="nama" class="w-20 font-semibold">Nama:</span>
           <span class="border border-gray-100 dark:border-gray-600 bg-gray-150 dark:bg-gray-700 rounded px-3 py-2 w-full"><?php echo e($dosenTerpilih->nama ?? ''); ?></span>
       </div>
   </div>
<?php endif; ?>

<div x-data="{ hovering: false }" class="overflow-x-auto w-60 sm:w-150 md:w-240 xl:min-w-full mt-1 pb-3">
   <table id="data-rekap-dosen" class="text-sm text-left w-full pt-4 display nowrap">
       <thead class="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-white sticky top-0 z-10">
           <tr>
               <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">No</th>
               <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">Program Studi</th>
               <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">Semester</th>
               <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">Mata Kuliah</th>
               <?php for($i = 1; $i <= $totalPertemuan; $i++): ?>
                   <th class="border border-gray-300 dark:border-gray-600 px-4 py-2 text-center"><?php echo e($i); ?></th>
               <?php endfor; ?>
               <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">%Mengajar</th>
           </tr>
       </thead>
       <tbody class="text-center dark:text-white">
           <?php if(count($rekap)): ?>
               <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr class="hover:bg-gray-50 dark:hover:bg-gray-800">
                   <td class="border border-gray-300 dark:border-gray-600 px-4 py-2"><?php echo e($loop->iteration); ?></td>
                   <td class="border border-gray-300 dark:border-gray-600 px-4 py-2"><?php echo e($item['nama_prodi']); ?></td>
                   <td class="border border-gray-300 dark:border-gray-600 px-4 py-2"><?php echo e($item['semester']); ?></td>
                   <td class="border border-gray-300 dark:border-gray-600 px-4 py-2"><?php echo e($item['nama_matkul']); ?></td>
                   <?php for($i = 0; $i < $totalPertemuan; $i++): ?>
                       <?php
                           $status = $item['status_pertemuan'][$i] ?? '-';
                           $bg = match($status) {
                                'M' => 'text-green-500',
                                '-' => 'text-gray-500',
                                'UTS' => 'text-red-500',
                                'UAS' => 'text-red-500',
                                default => 'text-gray-400', // fallback kalau null / tidak sesuai
                           };
                       ?>
                       <td class="border border-gray-300 dark:border-gray-600 px-4 py-2 font-semibold <?php echo e($bg); ?>" title="<?php echo e($item['nama_dosen']); ?>"><?php echo e($status); ?></td>
                   <?php endfor; ?>
                   <td class="border border-gray-300 dark:border-gray-600 px-4 py-2"><?php echo e($item['total_pertemuan']); ?></td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
       </tbody>
   </table>
</div>

<div class="mt-6">
   <h2 class="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-5">Keterangan:</h2>
   <p class="mt-2"><span class="text-green-500 font-bold p-1">M</span> = Mengajar</p>
   <p class="mt-2"><span class="text-gray-500 font-bold p-1 ">-</span> = Tidak Terselenggara Perkuliahan</p>
</div>

</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project_web_sem4-main lokal\resources\views/admin/rekap-dosen.blade.php ENDPATH**/ ?>