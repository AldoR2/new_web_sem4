<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/dosen/data-presensi.js']); ?>

    <div class="h-full dark:bg-gray-700 dark:text-white">
         <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>

        <p class="text-gray-800 dark:text-gray-200">Data Presensi Hari ini</p>

        <div class="w-full overflow-x-auto max-w-full mt-5 p-5 bg-white dark:bg-gray-800 rounded-sm shadow-xl">
            <div class="flex flex-col md:flex-row">
                <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0 md:mr-8">
                    <label for="filter-presensi" class="mb-1 font-semibold text-gray-800 dark:text-gray-200">Filter Data Perkuliahan:</label>
                    <select id="filter-presensi" name="prodi_id" class="bg-white dark:bg-gray-700 dark:text-white border border-gray-300 dark:border-gray-600 rounded-sm px-2 py-2">
                        <option value="" hidden selected>Pilih Program Studi</option>
                        <option value="today">Hari ini</option>
                        <option value="week">Minggu Ini</option>
                        <option value="month">Bulan ini</option>
                        <option value="all">Semua Periode</option>
                        
                    </select>
                </div>
                <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0">
                    <label for="filter-status" class="mb-1 font-semibold text-gray-800 dark:text-gray-200">Filter Status Perkuliahan:</label>
                    <select id="filter-status" class="bg-white dark:bg-gray-700 dark:text-white border border-gray-300 dark:border-gray-600 rounded-sm px-2 py-2">
                        <option value="">Semua Status</option>
                        <option value="aktif">Aktif</option>
                        <option value="uts">UTS</option>
                        <option value="uas">UAS</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="w-full overflow-x-auto max-w-full mt-5 p-5 bg-white dark:bg-gray-800 rounded-sm shadow-xl">
            <div class="mb-10 flex">
                <a href="<?php echo e(route('dosen.presensi.create')); ?>">
                    <button class="flex items-center px-4 py-2.5 text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-sm font-semibold cursor-pointer">
                        <i class="bi bi-plus-square-fill mr-2"></i>
                        <span>Tambah</span>
                    </button>
                </a>
            </div>

            <div class="overflow-x-auto w-[270px] sm:w-150 md:w-full mt-3 pb-3">
                <table id="data-presensi" class="text-sm w-full display pt-1 dark:text-white nowrap">
                    <thead class="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-100 sticky top-0 z-10">
                        <tr class="!text-center">
                            <th class="dark:border-gray-600 px-4 py-2">Tanggal</th>
                            <th class="dark:border-gray-600 px-4 py-2">Jam Perkuliahan</th>
                            <th class="dark:border-gray-600 px-4 py-2">Mata Kuliah</th>
                            <th class="dark:border-gray-600 px-4 py-2">Pertemuan Ke</th>
                            <th class="dark:border-gray-600 px-4 py-2">Program Studi</th>
                            <th class="dark:border-gray-600 px-4 py-2 !text-center">Semester</th>
                            <th class="dark:border-gray-600 px-4 py-2">Ruangan</th>
                            <th class="dark:border-gray-600 px-4 py-2">Status Perkuliahan</th>
                            <th class="dark:border-gray-600 px-4 py-2 !text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $presensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($p->tgl_presensi ?? '-'); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e(substr($p->jam_awal,0,5) .' - '. substr($p->jam_akhir,0,5) ?? '-'); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($p->pertemuan->matkul->nama_matkul ?? '-'); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2 text-center"><?php echo e($p->pertemuan->pertemuan_ke ?? '-'); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($p->pertemuan->prodi->nama_prodi ?? '-'); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2 text-center"><?php echo e($p->pertemuan->semester ?? '-'); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2"><?php echo e($p->ruangan->nama_ruangan ?? '-'); ?></td>
                                <td class=" dark:border-gray-600 px-4 py-2 text-center">
                                    <?php switch($p->pertemuan->status):
                                        case ('aktif'): ?>
                                            <span class="inline-block px-3 py-1 text-sm font-semibold text-white bg-green-500 rounded-full">Aktif</span>
                                        <?php break; ?>
                                        <?php case ('uts'): ?>
                                            <span class="inline-block px-3 py-1 text-sm font-semibold text-white bg-red-500 rounded-full">UTS</span>
                                        <?php break; ?>
                                        <?php case ('uas'): ?>
                                            <span class="inline-block px-3 py-1 text-sm font-semibold text-white bg-red-500 rounded-full">UAS</span>
                                        <?php break; ?>
                                        <?php case ('libur'): ?>
                                            <span class="inline-block px-3 py-1 text-sm font-semibold text-white bg-red-500 rounded-full">Libur</span>
                                        <?php break; ?>
                                        <?php default: ?>
                                            <span class="inline-block px-3 py-1 text-sm font-semibold text-white bg-gray-500 rounded-full">-</span>
                                    <?php endswitch; ?>
                                </td>
                                <td class=" dark:border-gray-600 px-4 py-2 text-center">
                                    <div class="flex justify-center gap-2">
                                        <a href="<?php echo e(route('dosen.presensi.edit', $p->id)); ?>">
                                            <button class="cursor-pointer px-2 py-1 bg-yellow-600 hover:bg-yellow-700 active:bg-yellow-800 text-white rounded-md">
                                                <i class="bi bi-pencil-square text-lg"></i>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(route('dosen.presensi.show', $p->id)); ?>">
                                            <button class="cursor-pointer px-2 py-1 bg-gray-600 hover:bg-gray-700 active:bg-gray-800 text-white rounded-md">
                                                <i class="bi bi-card-text text-lg"></i>
                                            </button>
                                        </a>

                                        <form action="<?php echo e(route('dosen.presensi.destroy', $p->id)); ?>" method="POST" class="form-hapus inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="px-2 py-1 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white rounded-md">
                                                <i class="bi bi-trash text-lg"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\project_web_sem4-main lokal\resources\views/dosen/presensi.blade.php ENDPATH**/ ?>