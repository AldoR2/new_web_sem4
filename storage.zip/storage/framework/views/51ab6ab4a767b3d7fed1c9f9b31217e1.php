<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/admin/data-ruangan.js']); ?>
    <div class="relative dark:text-white">
     <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
    <p class="dark:text-gray-300">Lihat Data Ruangan</p>

    <?php if(session('success')): ?>
        <div class="p-4 mb-4 text-green-800 dark:text-green-200 rounded-lg bg-green-100 dark:bg-green-900" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div x-data="{openImport: false}" class="w-full overflow-x-auto max-w-full mt-5 p-5 bg-white dark:bg-gray-800 rounded-sm shadow-xl">
        <div class="mt-2 mb-5 flex gap-4">
            <a href="<?php echo e(route('admin.master-ruangan.create')); ?>">
                <button class="flex items-center px-4 py-2.5 text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-sm font-semibold cursor-pointer">
                    <i class="bi bi-plus-square-fill mr-2"></i>
                    <span>Tambah</span>
                </button>
            </a>
        </div>

        <div class="overflow-x-auto w-[270px] sm:w-150 md:w-full mt-3 pb-3">
            <table id="data-ruangan" class="text-sm text-left w-full pt-1 display nowrap">
                <thead class="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-100 sticky top-0 z-10">
                    <tr>
                        <th class=" dark:border-gray-600 px-4 py-2">No</th>
                        <th class=" dark:border-gray-600 px-4 py-2">Ruangan</th>
                        <th class=" dark:border-gray-600 px-4 py-2 !text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-800">
                            <td class=" dark:border-gray-600 px-4 py-2 text-gray-800 dark:text-gray-100"><?php echo e($loop->iteration); ?></td>
                            <td class=" dark:border-gray-600 px-4 py-2 text-gray-800 dark:text-gray-100"><?php echo e($r->nama_ruangan); ?></td>
                            <td class=" dark:border-gray-600 px-4 py-2 text-center">
                                <div class="flex justify-center gap-2">
                                    <a href="<?php echo e(route('admin.master-ruangan.edit', $r->id)); ?>">
                                        <button class="cursor-pointer px-2 py-1 bg-yellow-600 hover:bg-yellow-700 active:bg-yellow-800 text-white rounded-md">
                                            <i class="bi bi-pencil-square text-lg"></i>
                                        </button>
                                    </a>

                                    <form action="<?php echo e(route('admin.master-ruangan.destroy', $r->id)); ?>" method="POST" class="form-hapus inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="px-2 py-1 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white rounded-md">
                                            <i class="bi bi-trash text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project_web_sem4-main lokal\resources\views/admin/master_data/ruangan.blade.php ENDPATH**/ ?>