<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/admin/data-presensi.js']); ?>
    <div class="h-full dark:text-white">
         <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
        <p class="dark:text-white">Silahkan tambahkan data perkuliahan</p>
        <div class="w-full h-max max-w-full mt-5 p-8 bg-white rounded-sm shadow-xl dark:bg-gray-800">

            
            <form action="<?php echo e(isset($presensi) ? route('admin.presensi.update', $presensi->id) : route('admin.presensi.store')); ?>" method="POST" class="form-validasi">
            <?php echo csrf_field(); ?>
            <?php if(isset($presensi)): ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" id="edit_id" value="<?php echo e($presensi->id); ?>">
            <?php endif; ?>

                <div class="flex flex-col md:flex-row">
                    <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0 md:mr-8">
                        <label for="prodi" class="mb-1 font-semibold dark:text-white">Pilih Program Studi:</label>
                        <select id="prodi" name="prodi_id" class="w-full" required <?php if(isset($presensi)): ?> disabled <?php endif; ?>>
                            <option value="" hidden selected>Pilih Program Studi</option>
                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php if(old('prodi_id', $presensi->pertemuan->prodi_id ?? '') == $p->id): ?> selected <?php endif; ?>>
                                    <?php echo e($p->nama_prodi); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                            <?php if(isset($presensi)): ?>
                                <input type="hidden" name="prodi_id" value="<?php echo e($presensi->pertemuan->prodi_id); ?>">
                            <?php endif; ?>
                        <span class="text-red-600 text-sm" id="prodi_id_error">
                            <?php $__errorArgs = ['prodi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div class="flex flex-col w-full mb-4 md:w-1/2">
                        <label for="semester" class="mb-1 font-semibold dark:text-white">Pilih Semester:</label>
                        <select id="semester" name="semester" class="w-full" required <?php if(isset($presensi)): ?> disabled <?php endif; ?>>
                            <option value="" hidden selected>Pilih Senester</option>
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php if(old('semester', $presensi->pertemuan->semester ?? '') == $i): ?> selected <?php endif; ?>>
                                        Semester <?php echo e($i); ?>

                                    </option>
                                <?php endfor; ?>
                        </select>
                            <?php if(isset($presensi)): ?>
                                <input type="hidden" name="semester" value="<?php echo e($presensi->pertemuan->semester); ?>">
                            <?php endif; ?>
                        <span class="text-red-600 text-sm" id="semester_error">
                            <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>
                </div>

                <div class="flex flex-col md:flex-row">
                    <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0 md:mr-8">
                        <label for="matkul" class="mb-1 font-semibold dark:text-white">Pilih Matkul:</label>
                        <select id="matkul" name="matkul_id" class="w-full" required <?php if(isset($presensi)): ?> disabled <?php endif; ?> data-old="<?php echo e(old('matkul_id', $presensi->pertemuan->matkul_id ?? '')); ?>" data-matkul-text="<?php echo e($presensi->pertemuan->matkul->nama_matkul ?? ''); ?>">
                        </select>
                        <?php if(isset($presensi)): ?>
                            <input type="hidden" name="matkul_id" value="<?php echo e($presensi->pertemuan->matkul_id); ?>">
                        <?php endif; ?>
                        <span class="text-red-600 text-sm" id="matkul_id_error">
                            <?php $__errorArgs = ['matkul_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div class="flex flex-col w-full mb-4 md:w-1/2">
                        <label for="dosen" class="mb-1 font-semibold dark:text-white">Pilih Dosen:</label>
                        <select id="dosen" name="dosen_id" required <?php if(isset($presensi)): ?> disabled <?php endif; ?>>
                            <option value="" hidden selected>Pilih Dosen</option>
                            <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>" <?php if(old('dosen_id', $presensi->dosen_id ?? '') == $d->id): ?> selected <?php endif; ?>>
                                    <?php echo e($d->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                            <?php if(isset($presensi)): ?>
                                <input type="hidden" name="dosen_id" value="<?php echo e($presensi->dosen_id); ?>">
                            <?php endif; ?>
                        <?php $__errorArgs = ['dosen_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div x-data="{ status: '<?php echo e(old('status', $presensi->pertemuan->status ?? '')); ?>' }">
                    <div class="flex flex-col md:flex-row">
                        <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0 md:mr-8">
                            <label for="pertemuan" class="mb-1 font-semibold dark:text-white">Pertemuan Ke :</label>
                            <select id="pertemuan" name="pertemuan_ke" class="p-2 w-full border-2 border-gray-300 dark:border-gray-600 dark:bg-gray-600 dark:text-white rounded-sm" required>
                                <option value="" hidden selected>Pilih Pertemuan</option>
                                    <?php for($i = 1; $i <= 50; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php if(old('pertemuan_ke', $presensi->pertemuan->pertemuan_ke ?? '') == $i): ?> selected <?php endif; ?>>
                                            <?php echo e($i); ?>

                                        </option>
                                    <?php endfor; ?>
                            </select>
                            <span class="text-red-600 text-sm" id="pertemuan_ke_error">
                                <?php $__errorArgs = ['pertemuan_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>

                        <div class="flex flex-col w-full mb-4 md:w-1/2">
                            <label for="status" class="mb-1 font-semibold dark:text-white">Status Pertemuan:</label>
                            <select id="status" name="status" x-model="status"  class="p-2 w-full border-2 border-gray-300 dark:border-gray-600 dark:bg-gray-600 dark:text-white rounded-sm">
                                <option value="" hidden selected>Pilih Status</option>
                                <option value="aktif">Aktif</option>
                                <option value="libur">Libur</option>
                                <option value="uts">UTS</option>
                                <option value="uas">UAS</option>

                                
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

            
            
                <div class="flex flex-col md:flex-row">

                    <div class="flex flex-col w-full mb-4 md:w-1/2 mr-0 md:mr-8">
                        <label for="tgl_presensi" class="mb-1 font-semibold dark:text-white">Pilih Tanggal Perkuliahan:</label>
                        <input type="date" id="tgl_presensi" name="tgl_presensi" class="p-2 border-2 mt-1 border-gray-400 dark:border-gray-600 dark:bg-gray-600 dark:text-white rounded-sm" value="<?php echo e(old('tgl_presensi', $presensi->tgl_presensi ?? '')); ?>" placeholder="Masukkan tanggal presensi">
                        <span class="text-red-600 text-sm" id="tgl_presensi_error">
                            <?php $__errorArgs = ['tgl_presensi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                        <div class="flex flex-col w-full mb-4 md:w-1/2">
                        

                            <label for="jenis" class="mb-1 font-semibold dark:text-white">Jenis Perkuliahan:</label>
                            <select id="jenis" name="jenis" class="p-2 mt-1 w-full border-2 border-gray-300 dark:border-gray-600 dark:bg-gray-600 dark:text-white rounded-sm" x-bind:disabled="status && status !== 'aktif'">
                                <option value="" hidden selected>Pilih Jenis Perkuliahan</option>
                                <option value="teori" <?php echo e(old('jenis', $presensi->pertemuan->jenis ?? '') == 'teori' ? 'selected' : ''); ?>>Teori</option>
                                <option value="praktik" <?php echo e(old('jenis', $presensi->pertemuan->jenis ?? '') == 'praktik' ? 'selected' : ''); ?>>Praktik</option>
                            </select>
                            <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        

                    

                </div>

                <div class="flex flex-col md:flex-row" x-show="status && status !== 'libur'" x-transition x-cloak>
                    <div class="flex flex-col w-full mb-4 md:w-1/3 mr-0 md:mr-4">
                            <label for="ruangan" class="mb-1 font-semibold dark:text-white">Pilih Ruangan:</label>
                            <select id="ruangan" name="ruangan_id" class="w-full">
                                <option value="" hidden selected>Pilih Ruangan</option>
                                <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($r->id); ?>" <?php echo e(old('ruangan_id', $presensi->ruangan_id ?? '') == $r->id ? 'selected' : ''); ?>>
                                        <?php echo e($r->nama_ruangan); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-red-600 text-sm" id="ruangan_id_error">
                                <?php $__errorArgs = ['ruangan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                    </div>
                    <div class="flex flex-col w-full mb-4 md:w-1/3 mr-0 md:mr-4">
                        <label for="jam_awal" class="mb-1 font-semibold dark:text-white">Jam Mulai:</label>
                        <input type="time" id="jam_awal" name="jam_awal" value="<?php echo e(old('jam_awal', $presensi->jam_awal ?? '')); ?>" class="p-2 w-full border-2 border-gray-400 rounded-sm dark:bg-gray-600 dark:border-gray-600 dark:text-white" placeholder="Masukkan Jam Awal">
                        <span class="text-red-600 text-sm" id="jam_awal_error">
                            <?php $__errorArgs = ['jam_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>
                    <div class="flex flex-col w-full mb-4 md:w-1/3">
                        <label for="jam_akhir" class="mb-1 font-semibold dark:text-white">Jam Selesai:</label>
                        <input type="time" id="jam_akhir" name="jam_akhir" value="<?php echo e(old('jam_akhir', $presensi->jam_akhir ?? '')); ?>" class="p-2 w-full border-2 border-gray-400 dark:border-gray-600 rounded-sm dark:bg-gray-600 dark:text-white" placeholder="Masukkan Jam Akhir">
                        <span class="text-red-600 text-sm" id="jam_akhir_error">
                            <?php $__errorArgs = ['jam_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>
                </div>
            </div>
            

                <div class="w-full flex justify-end">
                    <a href="<?php echo e(route('admin.presensi.index')); ?>" class="mr-2 px-5 py-2 bg-red-500 hover:bg-red-600 active:bg-red-700 text-white font-semibold rounded-md cursor-pointer">
                        Batal
                    </a>
                    <button type="submit" class="px-5 py-2 bg-green-600 hover:bg-green-700 active:bg-green-800 text-white rounded-md font-semibold cursor-pointer">Simpan</button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project_web_sem4-main lokal\resources\views/admin/form-presensi.blade.php ENDPATH**/ ?>