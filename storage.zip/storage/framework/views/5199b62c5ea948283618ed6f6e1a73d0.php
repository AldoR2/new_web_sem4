<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/stipress.png')); ?>">
  <title><?php echo e($title ?? 'Login'); ?> | STIPRES</title>
  <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
      <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <?php endif; ?>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body class="antialiased bg-gray-100 font-sans">

    
        <main data-aos="flip-right">
            <?php echo e($slot); ?>

        </main>
    

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
        duration: 500,
        offset: 120,
        once: true,
        mirror: false,
    });
    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\project_web_sem4-main lokal\resources\views/components/layoutAuth.blade.php ENDPATH**/ ?>